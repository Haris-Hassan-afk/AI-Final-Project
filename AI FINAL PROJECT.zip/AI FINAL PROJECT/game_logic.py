import random
import heapq
import os
from math import sqrt

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

BOARD_SIZE = 32
SECTION_SIZE = 5
WALL = '#'
EXIT = 'E'
EMPTY = '.'
PLAYER1 = 'P1'
PLAYER2 = 'P2'
GUARD = 'G'
DIAMOND = 'D'

def roll_dice():
    return random.randint(1, 6)

def roll_two_dice():
    return random.randint(1, 6) + random.randint(1, 6)

class Position:
    def __init__(self, x, y):
        if not (0 <= x < BOARD_SIZE and 0 <= y < BOARD_SIZE):
            raise ValueError(f"Invalid position ({x}, {y}) for board")
        self.x = x
        self.y = y

    def distance_to(self, other):
        return abs(self.x - other.x) + abs(self.y - other.y)

    def neighbors(self):
        directions = [(1,0), (-1,0), (0,1), (0,-1)]
        return [Position(self.x+dx, self.y+dy) for dx, dy in directions 
                if 0 <= self.x+dx < BOARD_SIZE and 0 <= self.y+dy < BOARD_SIZE]

    def __eq__(self, other):
        if other is None:
            return False
        return self.x == other.x and self.y == other.y
    
    # Add this for safety
    def __ne__(self, other):
        return not self.__eq__(other)

    def __lt__(self, other):
        return (self.x, self.y) < (other.x, other.y)

    def __hash__(self):
        return hash((self.x, self.y))

class Player:
    def __init__(self, position, symbol):
        self.position = position
        self.symbol = symbol
        self.has_diamond = False
        self.original_exit = position
        self.is_camouflaged = False
        self.camouflage_duration = 0
        self.steal_cooldown = 0

class Guard:
    def __init__(self, game):
        self.game = game
        self.position = self.find_valid_spawn()
        self.path = []
        self.sight_range = 2
        self.patrol_algorithm = random.choice(['circle', 'zigzag', 'random'])
        self.patrol_path = self.generate_patrol_path()
        self.patrol_index = 0
        self.investigating_noise = False
        self.noise_target = None
        self.is_stunned = False
        self.stun_duration = 0
        self.last_move_direction = None

    def respawn(self):
        """Move guard to a new valid random position"""
        self.position = self.find_valid_spawn()
        self.path = []
        self.patrol_index = 0
        self.investigating_noise = False
        self.noise_target = None

    def find_valid_spawn(self):
        while True:
            pos = self.game.get_random_empty_position()
            
            # Minimum distance from exits
            exit_distances = [pos.distance_to(exit_pos) for exit_pos in self.game.exits]
            too_close_to_exit = any(dist < 8 for dist in exit_distances)  # 8 tiles from exits
            
            # Minimum distance from players
            player_distances = [pos.distance_to(p.position) for p in self.game.players]
            too_close_to_player = any(dist < 8 for dist in player_distances)
            
            # Minimum distance from other guards
            guard_distances = [pos.distance_to(g.position) for g in self.game.guards if g != self]
            too_close_to_guard = any(dist < 6 for dist in guard_distances)
            
            if not too_close_to_exit and not too_close_to_player and not too_close_to_guard:
                return pos

    def line_of_sight(self, target):
        dx = target.x - self.position.x
        dy = target.y - self.position.y
        steps = max(abs(dx), abs(dy))
        if steps == 0:
            return True
        for i in range(steps + 1):
            x = self.position.x + round(i * dx / steps)
            y = self.position.y + round(i * dy / steps)
            if self.game.board[x][y] == WALL:
                return False
        return True

    def generate_patrol_path(self):
        center = Position(BOARD_SIZE//2, BOARD_SIZE//2)
        if self.patrol_algorithm == 'circle':
            return [Position(center.x + 5, center.y), Position(center.x - 5, center.y), 
                    Position(center.x, center.y + 5), Position(center.x, center.y - 5)]
        elif self.patrol_algorithm == 'zigzag':
            return [self.game.get_random_empty_position() for _ in range(8)]
        elif self.patrol_algorithm == 'random':
            return [self.game.get_random_empty_position() for _ in range(10)]
        return []

    def detect_noise(self):
        for noise in self.game.noise_events:
            if self.position.distance_to(noise['position']) <= 5:
                self.investigating_noise = True
                self.noise_target = noise['position']
                return True
        return False

    def detect_player(self):
        for player in self.game.players:
            if player.is_camouflaged:
                continue
            if self.position.distance_to(player.position) <= self.sight_range and \
               self.line_of_sight(player.position):
                return player
        return None

    def a_star(self, start, end):
        heap = [(0, start)]
        came_from = {}
        cost_so_far = {start: 0}
        while heap:
            current = heapq.heappop(heap)[1]
            if current == end:
                break
            for neighbor in current.neighbors():
                is_diamond = (self.game.diamond is not None and 
                             neighbor == self.game.diamond)
                
                if (self.game.board[neighbor.x][neighbor.y] == WALL or 
                    is_diamond):
                    continue
                new_cost = cost_so_far[current] + 1
                if neighbor not in cost_so_far or new_cost < cost_so_far[neighbor]:
                    cost_so_far[neighbor] = new_cost
                    priority = new_cost + sqrt((neighbor.x-end.x)**2 + (neighbor.y-end.y)**2)
                    heapq.heappush(heap, (priority, neighbor))
                    came_from[neighbor] = current
        path = []
        current = end
        while current != start:
            path.append(current)
            current = came_from.get(current, start)
        path.reverse()
        return path[:1]

    def move(self):
        if self.is_stunned:
            self.stun_duration -= 1
            if self.stun_duration <= 0:
                self.is_stunned = False
            return

        possible_moves = []
        for dx, dy in [(1,0), (-1,0), (0,1), (0,-1)]:
            new_x, new_y = self.position.x + dx, self.position.y + dy
            if self.last_move_direction and (dx, dy) == (-self.last_move_direction[0], -self.last_move_direction[1]):
                continue
            if 0 <= new_x < BOARD_SIZE and 0 <= new_y < BOARD_SIZE and self.game.board[new_x][new_y] != WALL:
                possible_moves.append((dx, dy))

        if not possible_moves:
            possible_moves = [(dx, dy) for dx, dy in [(1,0), (-1,0), (0,1), (0,-1)]
                            if 0 <= self.position.x+dx < BOARD_SIZE and 0 <= self.position.y+dy < BOARD_SIZE
                            and self.game.board[self.position.x+dx][self.position.y+dy] != WALL]

        if possible_moves:
            if self.detect_player():
                self.path = self.a_star(self.position, self.detect_player().position)
            elif self.detect_noise():
                self.path = self.a_star(self.position, self.noise_target)
            else:
                dx, dy = random.choice(possible_moves)
                self.path = [Position(self.position.x + dx, self.position.y + dy)]

            if self.path:
                self.last_move_direction = (self.path[0].x - self.position.x, self.path[0].y - self.position.y)
                self.game.clear_position(self.position)
                self.position = self.path[0]
                self.game.update_board(self.position, GUARD)

                for player in self.game.players:
                    if self.position == player.position:
                        self.game.clear_position(player.position)
                        player.position = player.original_exit
                        self.game.update_board(player.position, player.symbol)

    def stun(self, distance):
        self.is_stunned = True
        self.stun_duration = max(1, 6 - distance)

class Game:
    def __init__(self):
        self.reset_game()

    def reset_game(self):
        self.board = [[WALL for _ in range(BOARD_SIZE)] for _ in range(BOARD_SIZE)]
        self.players = []
        self.exits = []
        self.guards = []
        self.diamond = None
        self.noise_events = []
        self.current_player_idx = 0
        self.patterns = self.load_5x5_patterns(os.path.join(BASE_DIR, "maze_patterns"))
        
        while not self.validate_paths():
            self.generate_maze()
            self.place_exits()
            self.place_players()
            self.place_entities()

    def can_steal(self, thief, target):
        """Check if stealing is possible"""
        return (thief.position.distance_to(target.position) == 1 and target.has_diamond and thief.steal_cooldown == 0)

    def steal_diamond(self, thief, target):
        """Transfer diamond with cooldown"""
        if self.can_steal(thief, target):
            target.has_diamond = False
            thief.has_diamond = True
            thief.steal_cooldown = 2
            return True
        return False

    def update_cooldowns(self):
        """Reduce cooldowns each turn"""
        for player in self.players:
            if player.steal_cooldown > 0:
                player.steal_cooldown -= 1

    def load_5x5_patterns(self, pattern_dir):
        patterns = []
        if not os.path.exists(pattern_dir):
            os.makedirs(pattern_dir)
            with open(os.path.join(pattern_dir, "default.txt"), "w") as f:
                f.write("#.#.#\n"*5)
        
        for filename in os.listdir(pattern_dir):
            if filename.endswith(".txt"):
                with open(os.path.join(pattern_dir, filename)) as f:
                    pattern = [list(line.strip()[:5]) for line in f.readlines()[:5]]
                    if len(pattern) == 5:
                        patterns.append(pattern)
        return patterns

    def generate_maze(self):
        for i in range(1, BOARD_SIZE-1):
            for j in range(1, BOARD_SIZE-1):
                self.board[i][j] = EMPTY

        sections = 6
        for x in range(sections):
            for y in range(sections):
                start_x = 1 + x * SECTION_SIZE
                start_y = 1 + y * SECTION_SIZE
                pattern = random.choice(self.patterns)
                for dx in range(SECTION_SIZE):
                    for dy in range(SECTION_SIZE):
                        abs_x = start_x + dx
                        abs_y = start_y + dy
                        if abs_x < BOARD_SIZE-1 and abs_y < BOARD_SIZE-1:
                            self.board[abs_x][abs_y] = pattern[dx][dy]

    def place_exits(self):
        mid = BOARD_SIZE // 2
        sides = [
            (0, mid),
            (BOARD_SIZE-1, mid),
            (mid, 0),
            (mid, BOARD_SIZE-1)
        ]
        self.exits = [Position(x, y) for x, y in sides]
        for exit in self.exits:
            self.board[exit.x][exit.y] = EXIT
            if exit.x == 0: self.board[1][exit.y] = EMPTY
            elif exit.x == BOARD_SIZE-1: self.board[BOARD_SIZE-2][exit.y] = EMPTY
            elif exit.y == 0: self.board[exit.x][1] = EMPTY
            else: self.board[exit.x][BOARD_SIZE-2] = EMPTY

    def place_players(self):
        spawns = random.sample(self.exits, 2)
        self.players = [
            Player(spawns[0], PLAYER1),
            Player(spawns[1], PLAYER2)
        ]
        for p in self.players:
            self.update_board(p.position, p.symbol)

    def place_entities(self):
        self.diamond = Position(BOARD_SIZE//2, BOARD_SIZE//2)
        self.update_board(self.diamond, DIAMOND)
        
        for _ in range(8):
            guard = Guard(self)
            while guard.position == self.diamond:
                guard.respawn()
            self.guards.append(guard)
            self.update_board(guard.position, GUARD)

    def validate_paths(self):
        return len(self.players) == 2 and all(self.is_reachable(p.position) for p in self.players)

    def is_reachable(self, start_pos):
        visited = set()
        queue = [start_pos]
        while queue:
            current = queue.pop(0)
            if current == self.diamond:
                return True
            for neighbor in current.neighbors():
                if neighbor not in visited and self.board[neighbor.x][neighbor.y] != WALL:
                    visited.add(neighbor)
                    queue.append(neighbor)
        return False

    def get_random_empty_position(self):
        while True:
            x = random.randint(1, BOARD_SIZE-2)
            y = random.randint(1, BOARD_SIZE-2)
            if self.board[x][y] == EMPTY and self.is_reachable(Position(x, y)):
                return Position(x, y)

    def update_board(self, pos, symbol):
        self.board[pos.x][pos.y] = symbol

    def clear_position(self, pos):
        self.board[pos.x][pos.y] = EMPTY

    def move_player(self, player, steps):
        directions = {'w': (-1,0), 's': (1,0), 'a': (0,-1), 'd': (0,1)}
        while steps > 0:
            move = input(f"Player {player.symbol[-1]} move (w/a/s/d), steps left {steps}: ").lower()
            if move not in directions:
                print("Invalid move. Use w/a/s/d.")
                continue

            dx, dy = directions[move]
            new_pos = Position(player.position.x + dx, player.position.y + dy)

            if 0 <= new_pos.x < BOARD_SIZE and 0 <= new_pos.y < BOARD_SIZE \
                    and self.board[new_pos.x][new_pos.y] != WALL:
                self.clear_position(player.position)
                player.position = new_pos
                
                if not player.has_diamond and player.position == self.diamond:
                    player.has_diamond = True
                    self.clear_position(self.diamond)
                    self.diamond = None
                    print(f"\n💎 {player.symbol} acquired the diamond! 💎\n")
                
                self.update_board(player.position, player.symbol)
                steps -= 1
                
                self.move_guards()
                
                if player.has_diamond and player.position == player.original_exit:
                    print(f"🎉 {player.symbol} escaped with the diamond! Winner! 🎉")
                    return True
                
                if any(g.position == p.position for g in self.guards for p in self.players):
                    print("🚨 Player captured! Game Over! 🚨")
                    return False
            else:
                print("Blocked! Choose another direction.")
        return False

    def move_guards(self):
        for guard in self.guards:
            self.clear_position(guard.position)
            guard.move()

            # Ensure guard doesn't step on diamond
            if self.diamond and guard.position == self.diamond:
                # Find alternative position
                for neighbor in guard.position.neighbors():
                    if (self.board[neighbor.x][neighbor.y] == EMPTY and 
                        not (self.diamond and neighbor == self.diamond)):
                        guard.position = neighbor
                        break

            self.update_board(guard.position, GUARD)

            for player in self.players:
                if guard.position == player.position:
                    if hasattr(self, 'sound_manager'):
                        self.sound_manager.play('captured')
                    # Handle diamond first
                    if player.has_diamond:
                        player.has_diamond = False
                        self.diamond = Position(BOARD_SIZE//2, BOARD_SIZE//2)
                        self.update_board(self.diamond, DIAMOND)
                    
                    # Reset player position
                    self.clear_position(player.position)
                    player.position = player.original_exit
                    self.update_board(player.position, player.symbol)
                    
                    # Respawn the capturing guard
                    self.clear_position(guard.position)
                    guard.respawn()
                    self.update_board(guard.position, GUARD)

                    # Ensure board is updated properly
                    if self.diamond:  # Redundant safety check
                        self.update_board(self.diamond, DIAMOND)

    def print_board(self):
        print("\n" + "-"*(BOARD_SIZE*2))
        for row in self.board:
            print(' '.join(row))
        print("-"*(BOARD_SIZE*2))

    def create_noise(self, position):
        if not hasattr(self, 'noise_events'):
            self.noise_events = []
        self.noise_events.append({'position': position, 'ttl': 1})

    def cleanup_noise(self):
        if hasattr(self, 'noise_events'):
            for noise in self.noise_events:
                noise['ttl'] -= 1
            self.noise_events = [n for n in self.noise_events if n['ttl'] > 0]
        else:
            self.noise_events = []

    def stun_nearby_guards(self, origin, max_range=5):
        for guard in self.guards:
            dist = guard.position.distance_to(origin)
            if dist <= max_range:
                guard.stun(dist)

    def play(self):
        while True:
            current_player = self.players[self.current_player_idx]
            self.print_board()
            input(f"Player {current_player.symbol[-1]}, press Enter to roll...")
            steps = roll_two_dice()
            print(f"Rolled {steps}!")

            self.cleanup_noise()

            if not self.move_player(current_player, steps):
                return

            for player in self.players:
                if player.has_diamond and player.position == player.original_exit:
                    print(f"{player.symbol} escaped with the diamond! Winner!")
                    return

            self.current_player_idx = (self.current_player_idx + 1) % 2

if __name__ == "__main__":
    game = Game()
    game.play()