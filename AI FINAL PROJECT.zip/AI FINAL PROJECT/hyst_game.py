# hyst_game.py - UI Improvements
import pygame
import os
import sys
from game_logic import Game, BOARD_SIZE, WALL, EXIT, EMPTY, PLAYER1, PLAYER2, GUARD, DIAMOND, roll_two_dice, Position

# Initialize pygame and sound
pygame.init()
pygame.mixer.init(frequency=44100, size=-16, channels=20)

class SoundManager:
    def __init__(self):
        self.sounds = {}
        base_dir = os.path.dirname(os.path.abspath(__file__))
        sound_dir = os.path.join(base_dir, "assets", "sounds")
        
        # Load all sound effects
        try:
            self.sounds = {
                'background': pygame.mixer.Sound(os.path.join(sound_dir, "background.mp3")),
                'move': pygame.mixer.Sound(os.path.join(sound_dir, "move.wav")),
                'flashbang': pygame.mixer.Sound(os.path.join(sound_dir, "flashbang.wav")),
                'camouflage': pygame.mixer.Sound(os.path.join(sound_dir, "camouflage.mp3")),
                'captured': pygame.mixer.Sound(os.path.join(sound_dir, "captured.flac")),
                'diamond': pygame.mixer.Sound(os.path.join(sound_dir, "diamond.wav")),
                'victory': pygame.mixer.Sound(os.path.join(sound_dir, "victory.mp3")),
                'dice': pygame.mixer.Sound(os.path.join(sound_dir, "dice.wav"))
            }
            
            # Set individual volumes
            self.sounds['background'].set_volume(0.25)
            self.sounds['move'].set_volume(1)
            self.sounds['flashbang'].set_volume(0.5)
            self.sounds['camouflage'].set_volume(0.7)
            self.sounds['captured'].set_volume(0.6)
            self.sounds['diamond'].set_volume(0.8)
            self.sounds['victory'].set_volume(0.5)
            self.sounds['dice'].set_volume(2)
            
            # Start background music
            pygame.mixer.Channel(0).play(self.sounds['background'], loops=-1)
            
        except Exception as e:
            print(f"Sound loading error: {e}")
            self.sounds = {}

    def play(self, name):
        """Play a sound effect on its own channel"""
        if name in self.sounds:
            # Use different channels for different sound types
            if name == 'move':
                pygame.mixer.Channel(1).play(self.sounds[name])
            elif name == 'flashbang':
                pygame.mixer.Channel(2).play(self.sounds[name])
            elif name == 'camouflage':
                pygame.mixer.Channel(3).play(self.sounds[name])
            elif name == 'captured':
                pygame.mixer.Channel(4).play(self.sounds[name])
            elif name == 'diamond':
                pygame.mixer.Channel(5).play(self.sounds[name])
            elif name == 'victory':
                pygame.mixer.Channel(6).play(self.sounds[name])
            elif name == 'dice':
                pygame.mixer.Channel(7).play(self.sounds[name])

# Initialize sound manager
sound_manager = SoundManager()

# Constants
CELL_SIZE = 24  # Slightly larger for better visuals
WIDTH = BOARD_SIZE * CELL_SIZE
HEIGHT = BOARD_SIZE * CELL_SIZE + 120  # More space for enhanced UI
FONT_SIZE = 24
UI_PANEL_HEIGHT = 120

# Colors
COLORS = {
    'background': (28, 28, 36),
    'ui_panel': (40, 40, 50),
    'text': (240, 240, 240),
    'highlight': (255, 215, 0),
    WALL: (60, 60, 80),
    EXIT: (100, 255, 100),
    EMPTY: (45, 45, 60),
    PLAYER1: (100, 150, 255),
    PLAYER2: (255, 100, 100),
    GUARD: (180, 120, 60),
    DIAMOND: (100, 255, 255),
    'steal_cooldown': (255, 80, 80),
    'ability_ready': (100, 255, 100)
}

# Create game window
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("HYST - Heist Your Stolen Treasure")
clock = pygame.time.Clock()

# Load fonts
try:
    title_font = pygame.font.Font("assets/fonts/Alien.ttf", 32)
    font = pygame.font.Font("assets/fonts/Roboto.ttf", FONT_SIZE)
    status_font = pygame.font.Font("assets/fonts/Roboto.ttf", FONT_SIZE-4)
except:
    # Fallback to system fonts
    title_font = pygame.font.SysFont("arial", 32, bold=True)
    font = pygame.font.SysFont("arial", FONT_SIZE)
    status_font = pygame.font.SysFont("arial", FONT_SIZE-4)

# Load textures (fallback to colored rectangles if not found)
try:
    TEXTURES = {
        WALL: pygame.transform.scale(pygame.image.load("assets/textures/wall.png"), (CELL_SIZE, CELL_SIZE)),
        EXIT: pygame.transform.scale(pygame.image.load("assets/textures/exit.png"), (CELL_SIZE, CELL_SIZE)),
        PLAYER1: pygame.transform.scale(pygame.image.load("assets/characters/thief_blue.png"), (CELL_SIZE, CELL_SIZE)),
        PLAYER2: pygame.transform.scale(pygame.image.load("assets/characters/thief_red.png"), (CELL_SIZE, CELL_SIZE)),
        GUARD: pygame.transform.scale(pygame.image.load("assets/characters/guard.png"), (CELL_SIZE, CELL_SIZE)),
        DIAMOND: [pygame.transform.scale(pygame.image.load(f"assets/items/diamond_{i}.png"), (CELL_SIZE, CELL_SIZE)) 
                 for i in range(4)]  # Animation frames
    }
    USE_TEXTURES = True
except:
    USE_TEXTURES = False

class Button:
    def __init__(self, x, y, width, height, text, color, hover_color):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.color = color
        self.hover_color = hover_color
        self.is_hovered = False
        
    def draw(self, surface):
        color = self.hover_color if self.is_hovered else self.color
        pygame.draw.rect(surface, color, self.rect, border_radius=5)
        pygame.draw.rect(surface, COLORS['highlight'], self.rect, 2, border_radius=5)
        
        text_surf = status_font.render(self.text, True, COLORS['text'])
        text_rect = text_surf.get_rect(center=self.rect.center)
        surface.blit(text_surf, text_rect)
        
    def check_hover(self, pos):
        self.is_hovered = self.rect.collidepoint(pos)
        return self.is_hovered
        
    def is_clicked(self, pos, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            return self.rect.collidepoint(pos)
        return False

# Game initialization
game = Game()
current_steps = 0
diamond_anim_frame = 0
last_frame_time = pygame.time.get_ticks()
animation_speed = 200  # ms per frame

# Create UI buttons
roll_button = Button(WIDTH-150, HEIGHT-110, 140, 40, "ROLL DICE", 
                    COLORS['ability_ready'], (100, 200, 100))
flashbang_button = Button(10, HEIGHT-110, 160, 40, "FLASHBANG (5)", 
                         COLORS['ability_ready'] if current_steps >=5 else COLORS['steal_cooldown'],
                         (200, 200, 100))
camouflage_button = Button(170, HEIGHT-110, 180, 40, "CAMOUFLAGE (3)", 
                          COLORS['ability_ready'] if current_steps >=3 else COLORS['steal_cooldown'],
                          (200, 200, 100))
steal_button = Button(WIDTH-150, HEIGHT-60, 140, 40, "STEAL (X)", 
                     COLORS['ability_ready'], (200, 100, 100))

def draw_board():
    global diamond_anim_frame, last_frame_time
    
    # Dark background
    screen.fill(COLORS['background'])
    
    # Draw grid with textures or colors
    for x in range(BOARD_SIZE):
        for y in range(BOARD_SIZE):
            rect = pygame.Rect(y*CELL_SIZE, x*CELL_SIZE, CELL_SIZE, CELL_SIZE)
            cell = game.board[x][y]
            
            if USE_TEXTURES:
                if cell == DIAMOND and game.diamond:
                    # Animated diamond
                    current_time = pygame.time.get_ticks()
                    if current_time - last_frame_time > animation_speed:
                        diamond_anim_frame = (diamond_anim_frame + 1) % 4
                        last_frame_time = current_time
                    screen.blit(TEXTURES[DIAMOND][diamond_anim_frame], rect)
                elif cell in TEXTURES:
                    screen.blit(TEXTURES[cell], rect)
                else:
                    pygame.draw.rect(screen, COLORS.get(cell, COLORS[EMPTY]), rect)
            else:
                pygame.draw.rect(screen, COLORS.get(cell, COLORS[EMPTY]), rect)
                if cell == DIAMOND and game.diamond:
                    # Animate diamond with color pulse
                    pulse = int(50 * (1 + pygame.time.get_ticks() % 1000 / 1000))
                    diamond_color = (100, 255-pulse, 255)
                    pygame.draw.rect(screen, diamond_color, rect.inflate(-4, -4), border_radius=2)
    
    # Draw UI panel
    pygame.draw.rect(screen, COLORS['ui_panel'], (0, HEIGHT-UI_PANEL_HEIGHT, WIDTH, UI_PANEL_HEIGHT))
    
    # Draw title
    title_text = title_font.render("HYST HEIST", True, COLORS['highlight'])
    screen.blit(title_text, (20, HEIGHT-UI_PANEL_HEIGHT+10))
    
    # Draw player info
    current_player = game.players[game.current_player_idx]
    player_text = font.render(f"Player {current_player.symbol[-1]}'s Turn", True, COLORS['text'])
    screen.blit(player_text, (20, HEIGHT-UI_PANEL_HEIGHT+50))
    
    # Draw steps remaining
    steps_text = font.render(f"Steps: {current_steps}", True, 
                           COLORS['highlight'] if current_steps > 0 else COLORS['text'])
    screen.blit(steps_text, (20, HEIGHT-UI_PANEL_HEIGHT+80))
    
    # Draw diamond status
    diamond_status = "P1" if game.players[0].has_diamond else "P2" if game.players[1].has_diamond else "None"
    diamond_text = font.render(f"Diamond: {diamond_status}", True, 
                             COLORS['highlight'] if diamond_status != "None" else COLORS['text'])
    screen.blit(diamond_text, (200, HEIGHT-UI_PANEL_HEIGHT+50))
    
    # Draw cooldowns
    cooldown_text = status_font.render(
        f"Steal CD: P1:{game.players[0].steal_cooldown} P2:{game.players[1].steal_cooldown}", 
        True, COLORS['text'])
    screen.blit(cooldown_text, (200, HEIGHT-UI_PANEL_HEIGHT+80))
    
    # Draw buttons
    flashbang_button.color = COLORS['ability_ready'] if current_steps >=5 else COLORS['steal_cooldown']
    camouflage_button.color = COLORS['ability_ready'] if current_steps >=3 else COLORS['steal_cooldown']
    
    mouse_pos = pygame.mouse.get_pos()
    for button in [roll_button, flashbang_button, camouflage_button, steal_button]:
        button.check_hover(mouse_pos)
        button.draw(screen)
    
    # Draw tooltips on hover
    if flashbang_button.is_hovered:
        tooltip = status_font.render("Stuns nearby guards for 1-5 turns", True, COLORS['text'])
        screen.blit(tooltip, (10, HEIGHT-UI_PANEL_HEIGHT+140))
    elif camouflage_button.is_hovered:
        tooltip = status_font.render("Become invisible to guards for 3 turns", True, COLORS['text'])
        screen.blit(tooltip, (10, HEIGHT-UI_PANEL_HEIGHT+140))
    elif steal_button.is_hovered:
        tooltip = status_font.render("Steal diamond from adjacent player", True, COLORS['text'])
        screen.blit(tooltip, (10, HEIGHT-UI_PANEL_HEIGHT+140))
    
    pygame.display.flip()

def handle_move(dx, dy):
    global current_steps
    
    current_player = game.players[game.current_player_idx]
    other_player = game.players[(game.current_player_idx + 1) % 2]
    
    # Calculate new position
    new_x = current_player.position.x + dx
    new_y = current_player.position.y + dy
    
    try:
        new_pos = Position(new_x, new_y)
    except ValueError:
        return False  # Invalid position
    
    # Check if move is valid
    if not (0 <= new_x < BOARD_SIZE and 0 <= new_y < BOARD_SIZE):
        return False
    
    if game.board[new_x][new_y] == WALL:
        return False
    
    # Update camouflage duration
    if current_player.is_camouflaged:
        current_player.camouflage_duration -= 1
        if current_player.camouflage_duration <= 0:
            current_player.is_camouflaged = False
    
    # Execute the move
    game.clear_position(current_player.position)
    current_player.position = new_pos
    
    # Diamond collection
    if game.diamond and not current_player.has_diamond and current_player.position == game.diamond:
        current_player.has_diamond = True
        game.clear_position(game.diamond)
        game.diamond = None
        sound_manager.play('diamond')
    
    # Check for steal attempt when adjacent
    if (current_player.position.distance_to(other_player.position) == 1 and 
        other_player.has_diamond and 
        current_player.steal_cooldown == 0):
        # Auto-attempt steal when moving next to player with diamond
        game.steal_diamond(current_player, other_player)
        sound_manager.play('diamond')
    
    # Update board and play sound
    game.update_board(current_player.position, current_player.symbol)
    sound_manager.play('move')
    current_steps -= 1
    
    # Move guards after player move
    game.move_guards()
    
    # Check win condition
    if current_player.has_diamond and current_player.position == current_player.original_exit:
        sound_manager.play('victory')
        game_over(f"Player {current_player.symbol[-1]} escapes with the diamond! Winner!")
        return True
    
    # Check for guard capture
    for guard in game.guards:
        if guard.position == current_player.position:
            # Handle diamond if player was carrying it
            if current_player.has_diamond:
                current_player.has_diamond = False
                game.diamond = Position(BOARD_SIZE//2, BOARD_SIZE//2)
                game.update_board(game.diamond, DIAMOND)
            
            # Reset player position
            game.clear_position(current_player.position)
            current_player.position = current_player.original_exit
            game.update_board(current_player.position, current_player.symbol)
            
            # Respawn the capturing guard
            game.clear_position(guard.position)
            guard.respawn()
            game.update_board(guard.position, GUARD)
            
            sound_manager.play('captured')
            game_over(f"Player {current_player.symbol[-1]} was captured!")
            return False
    
    # Check if steps are exhausted
    if current_steps <= 0:
        game.current_player_idx = (game.current_player_idx + 1) % 2
        game.update_cooldowns()
    
    return True

def game_over(message):
    # Dark overlay
    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 180))
    screen.blit(overlay, (0, 0))
    
    # Game over text
    text = title_font.render(message, True, COLORS['highlight'])
    text_rect = text.get_rect(center=(WIDTH/2, HEIGHT/2))
    screen.blit(text, text_rect)
    
    # Continue prompt
    prompt = font.render("Click anywhere to continue...", True, COLORS['text'])
    prompt_rect = prompt.get_rect(center=(WIDTH/2, HEIGHT/2 + 50))
    screen.blit(prompt, prompt_rect)
    
    pygame.display.flip()
    
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN or event.type == pygame.KEYDOWN:
                waiting = False
                game.reset_game()
                global current_steps
                current_steps = 0
                return

def main_loop():
    global current_steps
    
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            mouse_pos = pygame.mouse.get_pos()
            
            # Handle button clicks
            if roll_button.is_clicked(mouse_pos, event) and current_steps == 0:
                sound_manager.play('dice')
                current_steps = roll_two_dice()
            
            if flashbang_button.is_clicked(mouse_pos, event) and current_steps >= 5:
                player = game.players[game.current_player_idx]
                sound_manager.play('flashbang')
                game.stun_nearby_guards(player.position)
                current_steps -= 5
            
            if camouflage_button.is_clicked(mouse_pos, event) and current_steps >= 3:
                player = game.players[game.current_player_idx]
                sound_manager.play('camouflage')
                player.is_camouflaged = True
                player.camouflage_duration = 3
                current_steps -= 3
            
            if steal_button.is_clicked(mouse_pos, event) and current_steps > 0:
                current_player = game.players[game.current_player_idx]
                other_player = game.players[(game.current_player_idx + 1) % 2]
                if game.can_steal(current_player, other_player):
                    game.steal_diamond(current_player, other_player)
                    current_steps -= 1
            
            # Handle keyboard controls
            if event.type == pygame.KEYDOWN and current_steps > 0:
                if event.key == pygame.K_w:
                    handle_move(-1, 0)
                elif event.key == pygame.K_s:
                    handle_move(1, 0)
                elif event.key == pygame.K_a:
                    handle_move(0, -1)
                elif event.key == pygame.K_d:
                    handle_move(0, 1)
                elif event.key == pygame.K_f and current_steps >= 5:
                    player = game.players[game.current_player_idx]
                    game.stun_nearby_guards(player.position)
                    sound_manager.play('flashbang')
                    current_steps -= 5
                elif event.key == pygame.K_c and current_steps >= 3:
                    player = game.players[game.current_player_idx]
                    player.is_camouflaged = True
                    sound_manager.play('camouflage')
                    player.camouflage_duration = 3
                    current_steps -= 3
                elif event.key == pygame.K_x:
                    current_player = game.players[game.current_player_idx]
                    other_player = game.players[(game.current_player_idx + 1) % 2]
                    if game.can_steal(current_player, other_player):
                        game.steal_diamond(current_player, other_player)
                        current_steps -= 1
            
            # End turn when steps are exhausted
            if current_steps == 0 and len([e for e in pygame.event.get() if e.type == pygame.KEYDOWN and e.key == pygame.K_RETURN]) > 0:
                game.current_player_idx = (game.current_player_idx + 1) % 2
                game.update_cooldowns()
        
        draw_board()
        clock.tick(60)
    
    pygame.quit()

if __name__ == "__main__":
    main_loop()